public class Country {
    private String code;
    private String name;
    private String region;

public Country(String code, String name, String region) {
    this.code = code;
    this.name = name;
    this.region = region;

}
}
