import java.sql.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws SQLException {


        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        Statement cumle = null;
        ResultSet sonuc ;
        ArrayList<Country> countries = new ArrayList<Country>();
        try {
            connection = dbHelper.getConnection();

            cumle = connection.createStatement();
            sonuc = cumle.executeQuery("select Code,Name,Region from country");
            while (sonuc.next()) {
                countries.add(new Country(sonuc.getString("Code"),sonuc.getString("Name"),sonuc.getString("Region")));
            }
            System.out.println(countries.size());
        } catch (SQLException exception) {

            dbHelper.showErrorMessage(exception);

        }finally {
            connection.close();
        }
    }
}