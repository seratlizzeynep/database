import java.sql.*;

public class Main {

    public static void main(String[] args) throws SQLException {


        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        Statement cumle = null;
        ResultSet sonuc ;
        try {
            connection = dbHelper.getConnection();

            cumle = connection.createStatement();
            sonuc = cumle.executeQuery("select Code,Name,Region from country");
            while (sonuc.next()) {
                System.out.println(sonuc.getString("Name"));
            }
        } catch (SQLException exception) {

            dbHelper.showErrorMessage(exception);

        }finally {
            connection.close();
        }
    }
}