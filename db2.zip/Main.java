import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {


        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        try {
            connection = dbHelper.getConnection();

            System.out.println("Connected to the database successfully");
        } catch (SQLException exception) {

            dbHelper.showErrorMessage(exception);

        }
    }
}